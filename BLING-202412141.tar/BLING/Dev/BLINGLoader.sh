for bfunc in /etc/BLING/*.bfunc
do
	source $bfunc
done

