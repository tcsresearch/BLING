### Functions ###
function DisplayLine() {
	echo "__________________________________________________________________"
}

function ShowEmptyLine() {
	echo " "
}

### Main Program ###

ShowEmptyLine
DisplayLine
ShowEmptyLine
echo "Displaying Sizes of KFolders: "
du -sh `cat KFolders.list`
ShowEmptyLine
DisplayLine
ShowEmptyLine
echo "Displaying Sizes of rpmbuild/*: "
du -sh rpmbuild/*
ShowEmptyLine
DisplayLine
ShowEmptyLine

