This folder contains depricated prebuilt libraries for BLING genrated by the buildlib tool.
