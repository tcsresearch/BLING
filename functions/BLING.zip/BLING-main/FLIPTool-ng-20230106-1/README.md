# [DEPRICATED] FLIPTool-ng - Find Largest Installed Packages (FLIP) Tool - Next Generation
This utility works on RPM-based distributions such as Fedora/RHEL/CentOS.
  * This code is bing migrated into functions within BLING.
