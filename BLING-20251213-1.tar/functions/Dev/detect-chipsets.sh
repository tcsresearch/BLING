inxi -Fzxx
