systemctl set-default graphical.target
