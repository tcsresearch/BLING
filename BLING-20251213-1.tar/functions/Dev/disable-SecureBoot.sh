mokutil --sb-state
