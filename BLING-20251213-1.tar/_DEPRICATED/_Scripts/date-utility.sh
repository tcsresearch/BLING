## Date Utility ##
now=$(date +"%Y%m%d")
echo "Today is $now"
echo "Backups will display as $now-1"
## TODO: Get function to increment the number,
#            e.g. 20221001-1, 20221001-2, etc.
#

