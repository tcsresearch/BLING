rpm -qa --queryformat %10{size}
