<hr>
<h3> BUGS </h3> 
These scripts work, but with one flaw:
<ul> 
  <li><i>The filename and foldername are not correctly displayed in the output. </i></li>
</ul>
<hr>
<h3> TODO </h3>
<ul>
  <li>Enable Cecho and colorize output </li>
  <ul><li><i> Green for file/folder found. </i></li></ul>
  <ul><li><i> Red for file/folder NOT found. </i></li></ul>
</ul>
<hr>
