<h4> [DEPRICATED] KConfigTool - Linux Kernel Configuration Utility. </h4>
<hr>

> [!WARNING]
> This project has been merged into BLING as a function (KConfigTool.bfunc).
<hr>
