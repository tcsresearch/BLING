if [ -z "$1" ]; then
  echo "The first argument is null or empty."
else
  echo "The first argument is: $1"
fi



