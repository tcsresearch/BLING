dnf install https://download1.rpmfusion.org/free/fedora/rpmfusion-free-release-35.noarch.rpm
