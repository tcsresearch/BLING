fdupes --noprompt --delete _Kernels/updates _Kernels/updates-testing/
